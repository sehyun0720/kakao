package com.test.snslogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnsloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
